
const menu = document.querySelector('.menu')
const sidebar = document.querySelector('.links-container')
const close = document.querySelector('.close-btn')
const banner = document.querySelector('.banner')
menu.addEventListener('click', () => {
sidebar.style.right = '0'
})
close.addEventListener('click', () => {
sidebar.style.right = '-100vw'
})
const scrollLink = document.querySelectorAll('.scroll-link')
window.addEventListener('load', () => {

scrollLink.forEach(link => {
if(link.href === path){
link.style.color = '#71deb5'
link.style.fontWeight = "bold"
}
})
})
